<?php
require(ROOT_PATH . '/modules/Wiki/classes/Wiki.php');

$wiki = new Wiki();
$wiki->getPages();

$_POST = json_decode(file_get_contents("php://input"), true);
$target_user = new User($_GET['id']);
    if (!$target_user->data()) {
        die(json_encode(array('html' => 'User not found')));
    } else {
        $user_query = $user_query[0];
    }
    
$pageid = $_POST['pageid'];
$user_id = (int) $user->data()->id;

if (isset($_POST['liked'])) {
  if(!$wiki->isPageLikedByUser($user_id, $pageid)){
    $wiki->reaction($pageid, $user_id, true);
  }
  exit;
}
if (isset($_POST['unliked'])) {
  if($wiki->isPageLikedByUser($user_id, $pageid)){
    $wiki->reaction($pageid, $user_id, false);
  }
  exit;
}

die();
