<script src="<?php echo $this->resource('inc/js/jquery-3.5.1.min.js'); ?>"></script>
<script src="<?php echo $this->resource('inc/js/bootstrap.min.js'); ?>"></script>
</html>