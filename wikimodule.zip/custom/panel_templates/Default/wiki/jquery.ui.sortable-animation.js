/*!
 * jQuery UI Sortable Animation 0.0.1
 *
 * Copyright 2015, Egor Sharapov
 * Licensed under the MIT license.
 *
 * Depends:
 *  jquery.ui.sortable.js
 */ 
!function(a){"function"==typeof define&&define.amd?define(["jquery","jquery-ui"],a):a(jQuery)}(function($){var a={},b=function(b){var a,c=document.createElement("div");for(a=0;a<b.length;a++)if(void 0!=c.style[b[a]])return b[a];return""},c=!1;a.transform=b(["transform","WebkitTransform","MozTransform","OTransform","msTransform"]),a.transition=b(["transition","WebkitTransition","MozTransition","OTransition","msTransition"]),c=a.transform&&a.transition,$.widget("ui.sortable",$.ui.sortable,{options:{animation:0},_rearrange:function(i,h){var d,g,b={},e={},f=$.trim(this.options.axis);if(!parseInt(this.currentContainer.options.animation)||!f)return this._superApply(arguments);this._superApply(arguments),null!=h&&(d=$(h.item[0]),g=("up"==this.direction?"":"-")+d["x"==f?"width":"height"]()+"px",c?b[a.transform]=("x"==f?"translateX":"translateY")+"("+g+")":(b={position:"relative"})["x"==f?"left":"top"]=g,d.css(b),c?(b[a.transition]=a.transform+" "+this.options.animation+"ms",b[a.transform]="",e[a.transform]="",e[a.transition]="",setTimeout(function(){d.css(b)},0)):(e.top="",e.position="",d.animate({top:"",position:""},this.options.animation)),setTimeout(function(){d.css(e)},this.options.animation))}})})