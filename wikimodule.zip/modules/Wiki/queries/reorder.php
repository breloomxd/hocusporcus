<?php
require(ROOT_PATH . '/modules/Wiki/classes/Wiki.php');
require(ROOT_PATH . '/modules/Wiki/classes/Page.php');
$wiki = new Wiki();
$wiki->getPages();
$wiki->initPages(true);

$type = $_POST['type'];
$newOrder = $_POST['pages'];
if($wiki->reorder($type, $newOrder)){
  echo 'New order saved successfully!';
} else {
  echo 'Something went wrong with saving the new order.';
}
die();
