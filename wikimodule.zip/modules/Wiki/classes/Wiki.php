<?php

class Wiki {

    private $_db;
    private $pagesAmount=0;
    private $wikipages;
    private $wikipages_array = array();
    private $settings;

    public function __construct() {
        $this->_db = DB::getInstance();
    }

    public function getSettings(){
        $this->settings = $this->_db->get('wiki_settings', array('name', '=', 'home_page'))->results();
        return $this->settings[0]->value;
    }

    public function getPages() {
        $this->wikipages = $this->_db->orderWhere('wiki_pages', "id <> 0", 'list_order', 'ASC')->results();
        return $this->wikipages;
    }
    
    public function initPage($page){
        array_push($this->wikipages_array, $page);
    }

    public function getViewLink($link){
        return "/"."wiki"."/".$link;
    }

    public function updateViews($nameid){
        foreach($this->wikipages as $page){
            if($page->nameid == $nameid){
                $views = (int) $page->views;
                $this->_db->increment('wiki_pages', $page->id, 'views');
                break;
            }
        }
    }

    public function initPages($staffmode){
        foreach($this->wikipages as $page){
            $_page = new Page(
                Output::getClean($page->id),
                Output::getClean($page->title),
                Output::getClean($page->nameid),
                Output::getPurified(htmlspecialchars_decode($page->icon)),
                Output::getPurified(htmlspecialchars_decode($page->button)),
                Output::getPurified(htmlspecialchars_decode($page->context)),
                Output::getClean($page->list_order),
                Output::getClean($page->parent),
                $this->getSubPages($page, $staffmode)
            );
            $_page->setViews($page->views);
            $_page->setLikes($page->likes);
            $_page->setLikeable($page->likeable);
            $_page->setEnabled($page->enabled);
            $_page->setVisible($page->visible);
            $_page->setOriginalLink($this->getViewLink(Output::getClean($page->nameid)));
            $_page->setEditLink(URL::build('/panel/wiki/', 'action=edit&id=' . Output::getClean($page->id)));
            $_page->setDeleteLink(URL::build('/panel/wiki/', 'action=delete&id=' . Output::getClean($page->id)));
            $this->initPage($_page);
            $this->pagesAmount++;
        }
    }

    // Like System

    public function getLikesByPage($page){
        try{
            $data = $this->_db->get('wiki_likes', array('pageid', '=', $page))->results();
            $usersList = array();
            foreach($data as $d){
                $userObject = new User($d->user_id, 'id');
                $user = array(
                    'username' => $userObject->data()->username,
                    'avatar' => $userObject->getAvatar(),
                    'link' => $userObject->getProfileURL(),
                    'id' => $userObject->data()->id                
                );
                array_push($usersList, $user);
            }
            return $usersList;
        } catch(Throwable $e){ return null; }
    }

    public function isPageLikedByUser($user_id, $nameid){
        $status = false;
        try{
            $data = $this->_db->get('wiki_likes', array('user_id', '=', $user_id))->results();
            foreach($data as $liked)
            {
                if ($liked->pageid == $nameid)
                {
                    $status = true;
                    break;
                }
            }
        } catch(Throwable $e) { echo($e); }
        return $status;
    }

    public function isPageLikedByUserAsString($user_id, $nameid){
        try{
            $data = $this->_db->get('wiki_likes', array('user_id', '=', $user_id))->results();
            foreach($data as $liked)
            {
                if ($liked->pageid == $nameid){
                    return 'true';
                }
            }
        } catch(Throwable $e){ echo($e); return 'false'; }
        return 'false';
    }

    public function reaction($page, $user_id, $action){
        if($action){
            if($this->like($page, $user_id)){
                return true;
            } else {
                return false;
            }
        } else {
            if($this->unlike($page, $user_id)){
                return true;
            } else {
                return false;
            }
        }
    }

    public function reorder($type, $order){
        $status = false;
        foreach($this->getPagesArray() as $page){
            switch($type){
                case "parents":
                    if($page->getParent() == "null"){
                      foreach($order as $key=>$value){
                        if($value == $page->getID()){
                          $this->_db->update('wiki_pages', (int)$value, array('list_order' => (int)$key+1));
                          $status = true;
                        }
                      }
                    }
                    break;
                case "children":
                    if($page->getParent() != "null"){
                        foreach($order as $key=>$value){
                          if($value == $page->getID()){
                            $this->_db->update('wiki_pages', (int)$value, array('list_order' => (int)$key+1));
                            $status = true;
                          }
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        return $status;
    }

    public function like($nameid, $user_id){
        $status = false;
        foreach($this->wikipages as $page){
            if($page->nameid == $nameid){
                if(!$this->isPageLikedByUser($user_id, $nameid)){
                    if($this->_db->insert('wiki_likes', array('user_id' => $user_id,'pageid' => $nameid))){
                        $likes = (int) $page->likes;
                        $this->_db->increment('wiki_pages', $page->id, 'likes');
                        $status = true;
                    } else {
                        $status = false;
                    }
                    break;
                }
            }
        }
        return $status;
    }

    public function unlike($nameid, $user_id){
        $status = false;
        foreach($this->wikipages as $page){
            if($page->nameid == $nameid){
                if($this->isPageLikedByUser($user_id, $nameid)){
                    $like_record = $this->_db->get('wiki_likes', array('user_id', '=', $user_id))->results();
                    foreach($like_record as $record){
                        if($record->user_id == $user_id){
                            if($record->pageid == $page->nameid){
                                if($this->_db->delete('wiki_likes', array('id', '=', $record->id))){
                                    $this->_db->decrement('wiki_pages', $page->id, 'likes');
                                    $status = true;
                                } else {
                                    $this->_db->decrement('wiki_pages', $page->id, 'likes');
                                    $status = false;
                                }
                                break;
                            }
                        }
                    }
                    break;
                }
            }
        }
        return $status;
    }

    public function isEnabled($page){
        $status = false;
        try{
            if($page->isEnabled() == 1){
                $status = true;
            }
        } catch(Exception $e){ $e->getMessage(); }
        return $status;
    }

    public function isPage($page){
        $status = false;
        try{
            if($this->hasParent($page)){
                $status = true;
            }
        } catch(Exception $e){ $e->getMessage(); }
        return $status;
    }

    public function isCategory($page){
        $status = false;
        try{
            if(!$this->hasParent($page)){
                $status = true;
            }
        } catch(Exception $e){ $e->getMessage(); }
        return $status;
    }
    
    public function hasSub($page){
        if(isset($page->subpages) || !is_null($page->subpages) && !empty($page->subpages)){
            return true;
        } else {
            return false;
        }
    }

    public function hasParent($page){
        if(!is_null($page->getParent()) && $page->getParent() != "null" && !empty($page->getParent())) {
            return true;
        } else {
            return false;
        }
    }

    function isPageExists($page){
        foreach($this->wikipages as $spage){
            if($spage->nameid == $page){
                return true;
            }
        }
        return false;
    }

    function isPageLikeable($page){
        foreach($this->wikipages as $spage){
            if($spage->nameid == $page){
                if($spage->likeable) {
                    return true;
                }
            }
        }
        return false;
    }

    function isPageVisible($page){
        foreach($this->wikipages as $spage){
            if($spage->nameid == $page){
                if($spage->visible) {
                    return true;
                }
            }
        }
        return false;
    }

    function getSubPages($page, $staffmode){
        $output_array = array();
        foreach($this->wikipages as $spage){
            if(isset($spage->parent) || is_null($spage->parent) || $spage->parent != "null" || !empty($page->parent)){
                if($spage->parent == $page->nameid){
                    if($staffmode){
                        try{
                            array_push($output_array, array(
                                'id' => Output::getClean($spage->id),
                                'title' => Output::getClean($spage->title),
                                'nameid' => Output::getClean($spage->nameid),
                                'parent' => Output::getClean($spage->parent),
                                'views' => Output::getClean($spage->views),
                                'likes' => Output::getClean($spage->likes),
                                'likeable' => Output::getClean($spage->likeable),
                                'visible' => Output::getClean($spage->visible),
                                'enabled' => Output::getClean($spage->enabled),
                                'icon' => Output::getPurified(htmlspecialchars_decode($spage->icon)),
                                'button' =>Output::getPurified(htmlspecialchars_decode($spage->button)),
                                'context' => Output::getPurified(htmlspecialchars_decode($spage->context)),
                                'order' => Output::getClean($spage->list_order),
                                'original_link' => $this->getViewLink(Output::getClean($page->nameid)),
                                'edit_link' => (URL::build('/panel/wiki/', 'action=edit&id=' . Output::getClean($spage->id))),
                                'delete_link' => (URL::build('/panel/wiki/', 'action=delete&id=' . Output::getClean($spage->id)))
                            ));
                        } catch(Exception $e){}
                    } else {
                        if($spage->enabled == "1"){
                            try{
                                array_push($output_array, array(
                                    'id' => Output::getClean($spage->id),
                                    'title' => Output::getClean($spage->title),
                                    'nameid' => Output::getClean($spage->nameid),
                                    'parent' => Output::getClean($spage->parent),
                                    'views' => Output::getClean($spage->views),
                                    'likes' => Output::getClean($spage->likes),
                                    'likeable' => Output::getClean($spage->likeable),
                                    'visible' => Output::getClean($spage->visible),
                                    'enabled' => Output::getClean($spage->enabled),
                                    'icon' => Output::getPurified(htmlspecialchars_decode($spage->icon)),
                                    'button' => Output::getPurified(htmlspecialchars_decode($spage->button)),
                                    'context' => Output::getPurified(htmlspecialchars_decode($spage->context)),
                                    'order' => Output::getClean($spage->order),
                                    'original_link' => $this->getViewLink(Output::getClean($page->nameid)),
                                    'edit_link' => (URL::build('/panel/wiki/', 'action=edit&id=' . Output::getClean($spage->id))),
                                    'delete_link' => (URL::build('/panel/wiki/', 'action=delete&id=' . Output::getClean($spage->id)))
                                ));
                            } catch(Exception $e){}
                        }
                    }
                }
            }
        }
        return $output_array;
    }

    public function getPageButton($pageName){
        foreach($this->wikipages as $spage){
            if($spage->nameid == $pageName){
                return $spage->button;
            }
        }
    }

    public function getPageTitle($pageName){
        foreach($this->wikipages as $spage){
            if($spage->nameid == $pageName){
                return $spage->title;
            }
        }
    }
    public function getPageCategory($pageName){
        foreach($this->wikipages as $spage){
            if($spage->nameid == $pageName){
                return $spage->parent;
            }
        }
    }
    
    public function getPagesArray(){
        return $this->wikipages_array;
    }

    public function getPagesAmount(){
        return $this->pagesAmount;
    }

}
